package api;

public interface Game {

  void play();

}
