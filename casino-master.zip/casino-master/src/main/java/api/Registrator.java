package api;

public interface Registrator {

  User registerUser();

}
