package api;

public interface GameChooser {

  Game chooseGame(User user);

}
